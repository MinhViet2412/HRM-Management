# HRM System - Human Resource Management

A comprehensive Human Resource Management system built with modern technologies including NestJS, React, TypeScript, and PostgreSQL.

## 🚀 Features

### Core Modules
- **Authentication & Authorization**: JWT-based auth with role-based access control (Admin, HR, Manager, Employee)
- **Employee Management**: Complete CRUD operations for employee records
- **Attendance Tracking**: Check-in/out with automatic status calculation and overtime tracking
- **Leave Management**: Request, approve, and track employee leave requests
- **Payroll System**: Automated payroll generation with tax calculations and deductions
- **Reports & Analytics**: Comprehensive reporting for attendance, staffing, and payroll
- **Audit Logging**: Complete audit trail for all system activities

### Technical Features
- **RESTful API**: Well-documented API with Swagger integration
- **Database**: PostgreSQL with TypeORM for robust data management
- **Frontend**: Modern React application with TypeScript and Tailwind CSS
- **Authentication**: Secure JWT-based authentication with refresh tokens
- **Role-based Access**: Granular permissions based on user roles
- **Docker Support**: Complete containerization with docker-compose
- **Responsive Design**: Mobile-friendly interface

## 🛠️ Tech Stack

### Backend
- **NestJS** - Progressive Node.js framework
- **TypeScript** - Type-safe JavaScript
- **TypeORM** - Object-relational mapping
- **PostgreSQL** - Robust relational database
- **JWT** - JSON Web Tokens for authentication
- **bcrypt** - Password hashing
- **Swagger** - API documentation
- **Jest** - Testing framework

### Frontend
- **React 18** - Modern UI library
- **TypeScript** - Type-safe development
- **Vite** - Fast build tool
- **React Router** - Client-side routing
- **React Query** - Data fetching and caching
- **Tailwind CSS** - Utility-first CSS framework
- **Axios** - HTTP client
- **React Hook Form** - Form management
- **Lucide React** - Icon library

### DevOps
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **Nginx** - Web server and reverse proxy
- **PostgreSQL** - Database server
- **PgAdmin** - Database administration

## 📋 Prerequisites

- Node.js 18+ 
- npm or yarn
- Docker and Docker Compose (optional)
- PostgreSQL 15+ (if not using Docker)

## 🚀 Quick Start

### Option 1: Using Docker (Recommended)

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd hrm
   ```

2. **Start all services**
   ```bash
   docker-compose up -d
   ```

3. **Seed the database**
   ```bash
   docker-compose exec backend npm run seed
   ```

4. **Access the application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:3000
   - API Documentation: http://localhost:3000/api/docs
   - Database Admin: http://localhost:5050

### Option 2: Manual Setup

1. **Install dependencies**
   ```bash
   # Install root dependencies
   npm install
   
   # Install backend dependencies
   cd backend && npm install
   
   # Install frontend dependencies
   cd ../frontend && npm install
   ```

2. **Setup database**
   ```bash
   # Create PostgreSQL database
   createdb hrm_db
   
   # Or using Docker for database only
   docker run --name hrm-postgres -e POSTGRES_DB=hrm_db -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=password -p 5432:5432 -d postgres:15-alpine
   ```

3. **Configure environment**
   ```bash
   # Copy environment file
   cp backend/env.example backend/.env
   
   # Edit backend/.env with your database credentials
   ```

4. **Start development servers**
   ```bash
   # Start backend
   cd backend && npm run start:dev
   
   # Start frontend (in another terminal)
   cd frontend && npm run dev
   ```

5. **Seed the database**
   ```bash
   cd backend && npm run seed
   ```

## 🔐 Default Credentials

- **Admin User**: admin@company.com / admin123
- **Database**: postgres / password (if using Docker)

## 📁 Project Structure

```
hrm/
├── backend/                 # NestJS backend
│   ├── src/
│   │   ├── auth/           # Authentication module
│   │   ├── employees/      # Employee management
│   │   ├── attendance/     # Attendance tracking
│   │   ├── leave/          # Leave management
│   │   ├── payroll/        # Payroll system
│   │   ├── reports/        # Reporting module
│   │   ├── database/       # Database entities and seeds
│   │   └── ...
│   ├── Dockerfile
│   └── package.json
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/    # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── services/     # API services
│   │   ├── contexts/     # React contexts
│   │   └── ...
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml      # Docker orchestration
└── README.md
```

## 🔧 API Endpoints

### Authentication
- `POST /auth/login` - User login
- `POST /auth/register` - User registration
- `POST /auth/refresh` - Refresh access token
- `POST /auth/logout` - User logout

### Employees
- `GET /employees` - Get all employees
- `POST /employees` - Create employee
- `GET /employees/:id` - Get employee by ID
- `PATCH /employees/:id` - Update employee
- `DELETE /employees/:id` - Delete employee

### Attendance
- `POST /attendance/check-in` - Check in
- `POST /attendance/check-out` - Check out
- `GET /attendance/my-attendance` - Get my attendance
- `GET /attendance/date/:date` - Get attendance by date

### Leave Requests
- `POST /leave/request` - Create leave request
- `GET /leave/my-requests` - Get my leave requests
- `POST /leave/:id/approve` - Approve leave request
- `POST /leave/:id/reject` - Reject leave request

### Payroll
- `POST /payroll/generate/:period` - Generate payroll
- `GET /payroll/period/:period` - Get payroll by period
- `GET /payroll/employee/:employeeId` - Get employee payroll

### Reports
- `GET /reports/attendance-summary` - Attendance summary
- `GET /reports/staffing-by-department` - Staffing report
- `GET /reports/payroll-summary` - Payroll summary

## 🧪 Testing

```bash
# Backend tests
cd backend && npm run test

# Frontend tests
cd frontend && npm run test

# E2E tests
cd backend && npm run test:e2e
```

## 🚀 Deployment

### Production Build

```bash
# Build backend
cd backend && npm run build

# Build frontend
cd frontend && npm run build
```

### Docker Production

```bash
# Build and start production containers
docker-compose -f docker-compose.prod.yml up -d
```

## 📊 Database Schema

The system includes the following main entities:

- **Users** - System users with authentication
- **Roles** - User roles and permissions
- **Employees** - Employee information
- **Departments** - Organizational departments
- **Positions** - Job positions
- **Attendance** - Daily attendance records
- **LeaveRequests** - Employee leave requests
- **Payroll** - Monthly payroll records
- **AuditLog** - System activity logs

## 🔒 Security Features

- JWT-based authentication with refresh tokens
- Password hashing with bcrypt
- Role-based access control
- Input validation and sanitization
- SQL injection prevention with TypeORM
- CORS configuration
- Rate limiting (can be added)

## 📈 Performance Features

- Database indexing on frequently queried fields
- Connection pooling
- Query optimization
- Frontend code splitting
- Image optimization
- Caching strategies

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new features
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the API documentation at `/api/docs`
- Review the code comments and documentation

## 🔄 Version History

- **v1.0.0** - Initial release with core HRM features
  - Authentication and authorization
  - Employee management
  - Attendance tracking
  - Leave management
  - Payroll system
  - Reporting module
  - Docker support
